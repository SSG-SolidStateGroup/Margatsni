![Circle CI](https://circleci.com/gh/SSG-SolidStateGroup/Margatsni.png?circle-token=:circle-token) ![Circle CI](https://circleci.com/gh/SSG-SolidStateGroup/Margatsni.svg?style=shield&circle-token=:circle-token)

# Margatsni

  http://margatsni.xyz

A web based tool, Margatnsi is being developed by SolidStateGroup as an Instagram Photo Downloading service.

## Install Requirements for App
	$ pip install -r requirements.txt	

### Members:
* Ismail Abbas
* Oscar Alcaraz
* Brandon Nguyen
* Aaron Reyes
* Calvin Teng
